#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Supervised::Supervised" for configuration "Release"
set_property(TARGET Supervised::Supervised APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Supervised::Supervised PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Python::Python"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/./libSupervised.so"
  IMPORTED_SONAME_RELEASE "@rpath/libSupervised.so"
  )

list(APPEND _cmake_import_check_targets Supervised::Supervised )
list(APPEND _cmake_import_check_files_for_Supervised::Supervised "${_IMPORT_PREFIX}/./libSupervised.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
