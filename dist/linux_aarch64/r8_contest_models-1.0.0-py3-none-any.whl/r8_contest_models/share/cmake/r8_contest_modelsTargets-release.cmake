#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "r8_contest_models::r8_contest_models" for configuration "Release"
set_property(TARGET r8_contest_models::r8_contest_models APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(r8_contest_models::r8_contest_models PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Python::Python"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/./libr8_contest_models.so"
  IMPORTED_SONAME_RELEASE "libr8_contest_models.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS r8_contest_models::r8_contest_models )
list(APPEND _IMPORT_CHECK_FILES_FOR_r8_contest_models::r8_contest_models "${_IMPORT_PREFIX}/./libr8_contest_models.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
