#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "BasicAirToAirCombatModels01::BasicAirToAirCombatModels01" for configuration "Release"
set_property(TARGET BasicAirToAirCombatModels01::BasicAirToAirCombatModels01 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(BasicAirToAirCombatModels01::BasicAirToAirCombatModels01 PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Python::Python"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/./libBasicAirToAirCombatModels01.so"
  IMPORTED_SONAME_RELEASE "libBasicAirToAirCombatModels01.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS BasicAirToAirCombatModels01::BasicAirToAirCombatModels01 )
list(APPEND _IMPORT_CHECK_FILES_FOR_BasicAirToAirCombatModels01::BasicAirToAirCombatModels01 "${_IMPORT_PREFIX}/./libBasicAirToAirCombatModels01.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
