#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "BasicAgentUtility::BasicAgentUtility" for configuration "Release"
set_property(TARGET BasicAgentUtility::BasicAgentUtility APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(BasicAgentUtility::BasicAgentUtility PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Python::Python"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/./libBasicAgentUtility.so"
  IMPORTED_SONAME_RELEASE "@rpath/libBasicAgentUtility.so"
  )

list(APPEND _cmake_import_check_targets BasicAgentUtility::BasicAgentUtility )
list(APPEND _cmake_import_check_files_for_BasicAgentUtility::BasicAgentUtility "${_IMPORT_PREFIX}/./libBasicAgentUtility.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
