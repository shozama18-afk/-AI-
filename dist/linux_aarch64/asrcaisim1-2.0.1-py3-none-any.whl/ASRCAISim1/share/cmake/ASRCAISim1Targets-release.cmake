#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ASRCAISim1::Core" for configuration "Release"
set_property(TARGET ASRCAISim1::Core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ASRCAISim1::Core PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Python::Python"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/core/libCore.so"
  IMPORTED_SONAME_RELEASE "libCore.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS ASRCAISim1::Core )
list(APPEND _IMPORT_CHECK_FILES_FOR_ASRCAISim1::Core "${_IMPORT_PREFIX}/core/libCore.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
