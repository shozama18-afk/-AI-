// Copyright (c) 2024-2026 Air Systems Research Center, Acquisition, Technology & Logistics Agency(ATLA)
#pragma once
#include "../Common.h"
#include "DiscreteMultiDiscreteConversion.h"
#include "FuelManagementUtility.h"
#include "MissileRangeUtility.h"
#include "TeamOrigin.h"
#include "sortTrack2DByAngle.h"
#include "sortTrack3DByDistance.h"
#include "util/imitation/init.h"

namespace BasicAgentUtility {

namespace util{

void init(py::module &m);

}

}
